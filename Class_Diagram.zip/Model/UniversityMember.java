
import java.util.*;

/**
 * 
 */
public abstract class UniversityMember extends Class1 {

    /**
     * Default constructor
     */
    public UniversityMember() {
    }

    /**
     * 
     */
    public String firstName;

    /**
     * 
     */
    public String lastName;

    /**
     * 
     */
    public int ssNo;

}