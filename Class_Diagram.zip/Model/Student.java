
import java.util.*;

/**
 * 
 */
public class Student extends UniversityMember {

    /**
     * Default constructor
     */
    public Student() {
    }

    /**
     * 
     */
    public int matNo;

}