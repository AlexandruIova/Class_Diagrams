
/**
 * 
 */
public enum ESemester {
    winter,
    summer
}