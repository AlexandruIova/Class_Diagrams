
import java.util.*;

/**
 * 
 */
public class Support {

    /**
     * Default constructor
     */
    public Support() {
    }

    /**
     * 
     */
    public void role: ERole;

    /**
     * 
     */
    public float hours;

}