
import java.util.*;

/**
 * 
 */
public class Employee extends UniversityMember {

    /**
     * Default constructor
     */
    public Employee() {
    }

    /**
     * 
     */
    private int acctNo;

    /**
     * @return
     */
    public int getAcctNo() {
        // TODO implement here
        return 0;
    }

}