
/**
 * 
 */
public enum ERole {
    lecturer,
    tutor,
    examiner
}