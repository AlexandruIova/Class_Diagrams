
import java.util.*;

/**
 * 
 */
public class CourseExecution {

    /**
     * Default constructor
     */
    public CourseExecution() {
    }

    /**
     * 
     */
    public int year;

    /**
     * 
     */
    public ESemester semester;

}